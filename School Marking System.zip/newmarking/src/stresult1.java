
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class stresult1 extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    public stresult1() {
        initComponents();
        
        tableview();
    }
    
   

    
    
    public void tableview()
{     
        try{
    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","");
    String query = "SELECT `studentid`, `grade`, `year`, `science`, `maths`, `english` FROM `subject1` ";
    pst = con.prepareStatement(query);
    rs = pst.executeQuery();
    jTable1.setModel(DbUtils.resultSetToTableModel(rs));
            }
catch(Exception e)
  {
    
    
}
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        idbox = new javax.swing.JTextField();
        sciencebox = new javax.swing.JTextField();
        mathsbox = new javax.swing.JTextField();
        englishbox = new javax.swing.JTextField();
        gradebox = new javax.swing.JComboBox<>();
        yearbox = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel2.setText("STUDENT MARKS DETAILS...");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 80, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("STUDENT ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 300, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("YEAR");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 460, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("GRADE");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 380, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("MATHS");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 610, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("SCIENCE");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 540, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("ENGLISH");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 680, -1, -1));
        jPanel1.add(idbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 310, 250, 40));
        jPanel1.add(sciencebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 540, 250, 40));
        jPanel1.add(mathsbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 610, 250, 40));
        jPanel1.add(englishbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 680, 250, 40));

        gradebox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT", "6", "7", "8", "9", "10", "11" }));
        jPanel1.add(gradebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 390, 250, 40));

        yearbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT", "2020", "2021" }));
        jPanel1.add(yearbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 460, 250, 40));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton1.setText("ADD");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 880, 210, 40));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton2.setText("UPDATE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 880, 210, 40));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton3.setText("DELETE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 880, 210, 40));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton4.setText("CLEAR");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 880, 210, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT ID", "GRADE", "YEAR", "SCIENCE", "MATHS", "ENGLISH", "TOTAL MARKS", "AVEREAGE", "RANK"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 280, 960, 490));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0,100));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton6.setText("STUDENT INFORMATION");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, -1, -1));

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton7.setForeground(new java.awt.Color(204, 0, 0));
        jButton7.setText("STUDENT RESULT");
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 580, 330, 40));

        jButton8.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton8.setText("TEACHER INFORMATION");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, -1));

        jButton9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton9.setText("TEACHER SUBJECT");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 330, -1));

        jButton10.setBackground(new java.awt.Color(255, 255, 255));
        jButton10.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton10.setText("PRINCIPAL INFORMATION");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 330, -1));

        jButton12.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton12.setText("LOGOUT");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 740, 330, 40));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton5.setText("TEACHER REGISTRATION");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 660, 330, 40));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 990));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1413905 (1).jpg"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 1990, 1000));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1990, 1000));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
            try
      {
        String query = "INSERT INTO `subject1`(`studentid`, `grade`, `year`, `science`, `maths`, `english`) VALUES (?,?,?,?,?,?)";
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","");
        pst =  con.prepareStatement(query);
        pst.setString(1,idbox.getText());
        pst.setString(2,gradebox.getSelectedItem().toString());
        pst.setString(3,yearbox.getSelectedItem().toString());
        pst.setString(4,sciencebox.getText());
        pst.setString(5,mathsbox.getText());
        pst.setString(6,englishbox.getText());
        
        
        

        
        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Add successful");
         tableview();
      }
      catch(Exception e)
      {
       JOptionPane.showMessageDialog(null, "Incorrect Student Number");
      }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
           
      /*  try
          {
            String value1 = idbox.getText();
            String value2 = gradebox.getSelectedItem().toString();
            String value3 = yearbox.getSelectedItem().toString();
            String value4 = sciencebox.getText();
            String value5 = mathsbox.getText();
            String value6 = englishbox.getText();
            
            String query = "UPDATE `subject1` SET `grade`='[value-2]',`year`='[value-3]',`science`='[value-4]',`maths`='[value-5]',`english`='[value-6]' WHERE `studentid`='[value-1]'";
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","");
            pst=con.prepareStatement(query);
            pst.execute();
            JOptionPane.showMessageDialog(null,"Update successful" );
           tableview();
          }catch(Exception e)
          {
             JOptionPane.showMessageDialog(null,e ); 
          }
        */
      
      
        try
          {
            String value1 = idbox.getText();
            String value2 = gradebox.getSelectedItem().toString();
            String value3 = yearbox.getSelectedItem().toString();
            String value4 = sciencebox.getText();
            String value5 = mathsbox.getText();
            String value6 = englishbox.getText();
            
            
            String query = "UPDATE `subject1` SET `grade`='"+value2+"',`year`='"+value3+"',`science`='"+value4+"',`maths`='"+value5+"',`english`='"+value6+"' WHERE `studentid`='"+value1+"'";;
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","");
            pst=con.prepareStatement(query);
            pst.execute();
          
            tableview();
              JOptionPane.showMessageDialog(null,"Update successful" );
          }catch(Exception e)
          {
             JOptionPane.showMessageDialog(null,e ); 
          }
       
       
      /* try
        {
            String value1 = idbox.getText();
            String value2 = .getText();
            String value3= authorname.getText();
            String value4 = bookcetogery.getSelectedItem().toString();
            String value5 = bookcount.getText();
            String value6 = bookcase.getText();
            String value7 = bookprice.getText();

            String query = " UPDATE `bookdetails` SET `bookname`='"+value2+"',`authorname`='"+value3+"',`bookcetogery`='"+value4+"',`bookcount`='"+value5+"',`bookcase`='"+value6+"',`bookprice`='"+value7+"' WHERE  `bookid`='"+value1+"'";
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","");
            pst=con.prepareStatement(query);
            pst.execute();
           // JOptionPane.showMessageDialog(null,"Update successful" );
            //tableload();
              JOptionPane.showConfirmDialog(null, "book update successfuii");
                     setVisible(false);
                     new bookupdate().setVisible(true);
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e );
        }
*/
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        
            int r = jTable1.getSelectedRow();
       String id = jTable1.getValueAt(r,0).toString();
       String grade= jTable1.getValueAt(r,1).toString(); 
       String year= jTable1.getValueAt(r,2).toString();        
        String science = jTable1.getValueAt(r,3).toString();
        String maths = jTable1.getValueAt(r,4).toString();
        String english = jTable1.getValueAt(r,5).toString();
        
        
        idbox.setText(id);
        //namebox.setText(name);
        gradebox.setSelectedItem(grade);
        yearbox.setSelectedItem(year);
        
        sciencebox.setText(science);
        mathsbox.setText(maths);
        englishbox.setText(english);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       
          idbox.setText("");
      
      //namebox.setText("");
      
      gradebox.setSelectedIndex(0);
      
      yearbox.setSelectedIndex(0);  
      
      sciencebox.setText("");
      
      mathsbox.setText("");
      
      englishbox.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
        DefaultTableModel tb1Model = (DefaultTableModel) jTable1.getModel();
       
       if(jTable1.getSelectedRowCount()==1)
       {
           tb1Model.removeRow(jTable1.getSelectedRow());
            JOptionPane.showMessageDialog(null,"Delete successful");
       }
       
       else
       {
          if(jTable1.getRowCount()==0)
          {
              JOptionPane.showMessageDialog(this,"Table is Empty");
          } else{
              JOptionPane.showMessageDialog(this,"Please Select Single Row For Delete"); 
          }
       }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        teacherupdate p2 = new teacherupdate();
        p2.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
       teachersubject s2 = new teachersubject();
        s2.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
         studentupdate s1 = new studentupdate();
        s1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
         admin a3 = new admin();
        a3.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        
         mainpage m3 = new mainpage();
        m3.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        sign s3 = new sign();
        s3.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(stresult1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(stresult1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(stresult1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(stresult1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new stresult1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField englishbox;
    private javax.swing.JComboBox<String> gradebox;
    private javax.swing.JTextField idbox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField mathsbox;
    private javax.swing.JTextField sciencebox;
    private javax.swing.JComboBox<String> yearbox;
    // End of variables declaration//GEN-END:variables
}
