
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;


public class classreport extends javax.swing.JInternalFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    
    
    
    public classreport() {
        initComponents();
        
        tableadd();
        //search();
    }

    public void tableadd() {
        try{
            
         con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college?","root","");
         String query = "SELECT id,name,subject1.grade, subject1.year,subject1.science,subject1.maths,subject1.english FROM studentdetails INNER JOIN subject1 ON studentdetails.id=subject1.studentid";
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();
         jTable1.setModel(DbUtils.resultSetToTableModel(rs));
       
            
        }catch(Exception e){
            
         //JOptionPane.showMessageDialog(null, e);
        }
    
}
    
    /*public void search(){
        
         String srch = searchbox1.getText();
      try{
          
         
          String query = " SELECT id,name,subject1.grade, subject1.year,subject1.science,subject1.maths,subject1.english FROM studentdetails INNER JOIN subject1 ON studentdetails.id=subject1.studentid WHERE subject1.grade='"+srch+"'";
          pst = con.prepareStatement(query);
          rs = pst.executeQuery();
          jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          
          
      } catch(Exception e){
          
          JOptionPane.showMessageDialog(null, e);
      } 
        
        
    }
    
    /*public void search1(){
         String srch1 = searchbox1.getText();
         
         try{
             
             String query = "SELECT id,name,subject1.grade, subject1.year,subject1.science,subject1.maths,subject1.english FROM studentdetails INNER JOIN subject1 ON studentdetails.id=subject1.studentid WHERE subject1.grade='"+srch1+"'";
             pst = con.prepareStatement(query);
             rs = pst.executeQuery();
             jTable1.setModel(DbUtils.resultSetToTableModel(rs));
         }catch(Exception e){
          
             JOptionPane.showMessageDialog(null,e);
             
         }
    }*/
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        gradebox = new javax.swing.JTextField();
        yearbox = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT ID", "STUDENT NAME", "GRADE", "YEAR", "SCIENCE", "MATHS", "ENGLISH"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton1.setText("PRINT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(169, 169, 169)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 1020, 390));
        jPanel1.add(gradebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 170, 40));
        jPanel1.add(yearbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, 170, 40));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton2.setText("SEARCH");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 110, 160, 50));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("GRADE :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("YEAR :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, 70, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 0, 0));
        jLabel4.setText("CLASS REPORT");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1413905 (1).jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 570));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1040, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        MessageFormat header = new MessageFormat("I am Header of the Print Page");
        MessageFormat footer = new MessageFormat("page{0,number,integer}");
        
        try{
            
          jTable1.print(JTable.PrintMode.NORMAL, header, footer);
          
          
            
        }catch(Exception e){
            
            JOptionPane.showMessageDialog(null,e);
            
            
        } 
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
         String srch = gradebox.getText();
        String srch1 = yearbox.getText();

        try
        {
            String query = "SELECT id,name,subject1.grade,subject1.year,subject1.science,subject1.maths,subject1.english FROM studentdetails INNER JOIN subject1 ON studentdetails.id=subject1.studentid WHERE subject1.grade='"+srch+"' AND subject1.year='"+srch1+"'";
            //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","");
            pst =  con.prepareStatement(query);
            // pst.setString(1,idbox.getText());
            //pst.setString(2,namebox.getText());
            //pst.executeUpdate();
            //JOptionPane.showMessageDialog(null, "Add successful");
            //tableview();

            rs = pst.executeQuery();
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));

        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }

        
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField gradebox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField yearbox;
    // End of variables declaration//GEN-END:variables
}
